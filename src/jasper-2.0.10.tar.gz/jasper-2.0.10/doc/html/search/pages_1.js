var searchData=
[
  ['getting_20started',['Getting Started',['../getting_started.html',1,'']]]
];
