package com.hwloc.lstopo;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider { }
